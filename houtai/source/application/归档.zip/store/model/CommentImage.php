<?php

namespace app\store\model;

use app\common\model\CommentImage as CommentImageModel;

/**
 * 商品图片模型
 * Class GoodsImage
 * @package app\store\model
 */
class CommentImage extends CommentImageModel
{
}
