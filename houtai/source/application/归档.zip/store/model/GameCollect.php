<?php

namespace app\store\model;

use app\common\model\GameCollect as GameCollectModel;

/**
 * 局收藏模型
 * Class GameCollect
 * @package app\store\model
 */
class GameCollect extends GameCollectModel
{
}