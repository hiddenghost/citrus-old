<?php

namespace app\store\model;

use app\common\model\UserAddress as UserAddressModel;

/**
 * 用户收货地址模型
 * Class UserAddress
 * @package app\store\model
 */
class UserAddress extends UserAddressModel
{

}
