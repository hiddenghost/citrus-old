<?php

namespace app\store\model;

use app\common\model\GameImage as GameImageModel;

/**
 * 局图片模型
 * Class GameImage
 * @package app\store\model
 */
class GameImage extends GameImageModel
{
}