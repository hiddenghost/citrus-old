<?php

namespace app\store\model;

use app\common\model\OrderRefundImage as OrderRefundImageModel;

class OrderRefundImage extends OrderRefundImageModel
{

}