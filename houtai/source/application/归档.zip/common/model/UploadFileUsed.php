<?php

namespace app\common\model;

/**
 * 已上传文件使用记录表MO型
 * Class UploadFileUsed
 * @package app\common\model
 */
class UploadFileUsed extends BaseModel
{
    protected $name = 'upload_file_used';

}
