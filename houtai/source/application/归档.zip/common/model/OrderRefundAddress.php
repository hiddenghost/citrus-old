<?php

namespace app\common\model;

/**
 * 售后单退货地址模型
 * Class OrderRefundAddress
 * @package app\common\model
 */
class OrderRefundAddress extends BaseModel
{
    protected $name = 'order_refund_address';
    protected $updateTime = false;

}