<?php

namespace app\common\model\sharing;

use app\common\model\BaseModel;

/**
 * 自提订单联系方式模型
 * Class OrderExtract
 * @package app\common\model\sharing
 */
class OrderExtract extends BaseModel
{
    protected $name = 'sharing_order_extract';
    protected $updateTime = false;

}
