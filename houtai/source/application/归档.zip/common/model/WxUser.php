<?php

namespace app\common\model;

/**
 * 微信用户模型
 * Class WxUser
 * @package app\common\model
 */
class WxUser extends BaseModel
{
    protected $name = 'wx_user';


}
