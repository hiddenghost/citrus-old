<?php

namespace app\common\model;

/**
 * 商城模型
 * Class Store
 * @package app\common\model
 */
class Store extends BaseModel
{

}