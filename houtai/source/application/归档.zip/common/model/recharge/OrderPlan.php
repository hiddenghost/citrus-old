<?php

namespace app\common\model\recharge;

use app\common\model\BaseModel;

/**
 * 用户充值订单套餐快照模型
 * Class OrderPlan
 * @package app\common\model\recharge
 */
class OrderPlan extends BaseModel
{
    protected $name = 'recharge_order_plan';

}