<?php

namespace app\common\model\admin;

use app\common\model\BaseModel;

/**
 * 超管后台用户模型
 * Class User
 * @package app\common\model\admin
 */
class User extends BaseModel
{
    protected $name = 'admin_user';

}