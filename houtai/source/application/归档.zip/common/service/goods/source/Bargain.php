<?php

namespace app\common\service\goods\source;

/**
 * 商品来源-砍价商品扩展类
 * Class Bargain
 * @package app\common\service\goods\source
 */
class Bargain extends Master
{

}