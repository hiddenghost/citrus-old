<?php

namespace app\common\enum;

use MyCLabs\Enum\Enum;

/**
 * 枚举类基类
 * Class Basics
 * @package app\common\enum
 */
abstract class EnumBasics extends Enum
{

}