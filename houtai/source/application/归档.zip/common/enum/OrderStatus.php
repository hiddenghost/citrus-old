<?php

namespace app\common\enum;

/**
 * 订单状态枚举类
 * Class OrderStatus
 * @package app\common\enum
 */
class OrderStatus extends EnumBasics
{
    const ORDER_PAYMENT = 20;

}