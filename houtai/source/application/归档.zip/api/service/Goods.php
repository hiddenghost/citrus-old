<?php

namespace app\api\service;

use app\common\service\Goods as GoodsService;

/**
 * 商品服务类
 * Class Goods
 * @package app\api\service
 */
class Goods extends GoodsService
{

}