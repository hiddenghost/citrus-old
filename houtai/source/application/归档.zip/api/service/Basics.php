<?php

namespace app\api\service;

class Basics extends \app\common\service\Basics
{

}