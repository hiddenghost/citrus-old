<?php

namespace app\api\model;

use app\common\model\OrderExtract as OrderExtractModel;

/**
 * 自提订单联系方式模型
 * Class OrderExtract
 * @package app\api\model
 */
class OrderExtract extends OrderExtractModel
{

}