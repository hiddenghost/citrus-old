<?php

namespace app\api\model\wow;

use app\common\model\wow\Setting as SettingModel;

/**
 * 好物圈设置模型
 * Class Setting
 * @package app\api\model\wow
 */
class Setting extends SettingModel
{

}