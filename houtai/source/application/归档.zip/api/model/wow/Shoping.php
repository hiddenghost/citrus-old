<?php

namespace app\api\model\wow;

use app\common\model\wow\Shoping as ShopingModel;

/**
 * 好物圈商品收藏记录模型
 * Class Shoping
 * @package app\api\model\wow
 */
class Shoping extends ShopingModel
{

}