<?php

namespace app\api\model\sharing;

use app\common\model\sharing\OrderRefundImage as OrderRefundImageModel;

/**
 * 售后单图片模型
 * Class OrderRefundImage
 * @package app\api\model\sharing
 */
class OrderRefundImage extends OrderRefundImageModel
{

}