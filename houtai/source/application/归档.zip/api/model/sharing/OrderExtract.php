<?php

namespace app\api\model\sharing;

use app\common\model\sharing\OrderExtract as OrderExtractModel;

/**
 * 自提订单联系方式模型
 * Class OrderExtract
 * @package app\api\model\sharing
 */
class OrderExtract extends OrderExtractModel
{

}