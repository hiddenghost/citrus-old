<?php

namespace app\api\model\sharing;

use app\common\model\sharing\GoodsSpecRel as GoodsSpecRelModel;

/**
 * 拼团商品规格关系模型
 * Class GoodsSpecRel
 * @package app\api\model\sharing
 */
class GoodsSpecRel extends GoodsSpecRelModel
{
}
