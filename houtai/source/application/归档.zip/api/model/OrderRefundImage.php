<?php

namespace app\api\model;

use app\common\model\OrderRefundImage as OrderRefundImageModel;

/**
 * 售后单图片模型
 * Class OrderRefundImage
 * @package app\api\model
 */
class OrderRefundImage extends OrderRefundImageModel
{

}