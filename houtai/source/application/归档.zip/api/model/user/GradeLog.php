<?php

namespace app\api\model\user;

use app\common\model\user\GradeLog as GradeLogModel;

/**
 * 用户会员等级变更记录模型
 * Class GradeLog
 * @package app\api\model\user
 */
class GradeLog extends GradeLogModel
{

}