<?php

namespace app\api\model\user;

use app\common\model\user\Email as EmailModel;

/**
 * 用户邮箱模型
 * Class Email
 * @package app\api\model\user
 */
class Email extends EmailModel
{

}