<?php

namespace app\api\model;

use app\common\exception\BaseException;
use app\common\model\City as CityModel;

/**
 * City模型
 * Class City
 * @package app\api\model
 */
class City extends CityModel
{

}