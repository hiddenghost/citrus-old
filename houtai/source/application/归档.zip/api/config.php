<?php

return [
    // 默认输出类型
    'default_return_type' => 'json',
    // 默认全局过滤方法 用逗号分隔多个
    'default_filter' => 'trim,htmlspecialchars,filter_emoji',
];